DROP TABLE Reasignaciones

DROP TABLE Centro

CREATE TABLE Puesto (
Id_Puesto int PRIMARY KEY identity NOT NULL,
Puesto varchar (20),
Descripci�n_Puesto varchar (50) NOT NULL,
Centro_Trabajo varchar (20) NOT NULL,
Directivo varchar (20) NOT NULL
)

CREATE TABLE Directivo(
Id_Directivo int primary key NOT NULL,
Centro_Supervisado varchar (30) NOT NULL,
Prestaci�n_Combustible varchar (20) NOT NULL
)

SELECT * FROM Directivo

INSERT INTO Centro (Id_Centro, Nombre_Centro, Ciudad)
VALUES ('000201', 'Tiendas �ngel Flores Ropa', 'Culiac�n')
INSERT INTO Centro (Id_Centro, Nombre_Centro, Ciudad)
VALUES ('000202', 'Tienda �ngel flores Muebles', 'Culiac�n')
INSERT INTO Centro (Id_Centro, Nombre_Centro, Ciudad)
VALUES ('000203', 'Tienda �ngel flores Cajas', 'Culiac�n')
INSERT INTO Centro (Id_Centro, Nombre_Centro, Ciudad)
VALUES ('049001', 'La Primavera Ropa', 'Culiac�n')
INSERT INTO Centro (Id_Centro, Nombre_Centro, Ciudad)
VALUES ('049002', 'La Primavera Muebles', 'Culiac�n')
INSERT INTO Centro (Id_Centro, Nombre_Centro, Ciudad)
VALUES ('049003', 'La Primavera Cajas', 'Culiac�n')
INSERT INTO Centro (Id_Centro, Nombre_Centro, Ciudad)
VALUES ('037001', 'La Vida es Bella Ropa', 'Culiac�n')
INSERT INTO Centro (Id_Centro, Nombre_Centro, Ciudad)
VALUES ('051002', 'La Vida es Bella Muebles', 'Culiac�n')
INSERT INTO Centro (Id_Centro, Nombre_Centro, Ciudad)
VALUES ('051003', 'La Vida es Bella Cajas', 'Culiac�n')

UPDATE Centro SET Nombre_Centro= 'La Vida es Bella Cajas' where id_Centro=051001

CREATE TABLE Centro (
Id_Centro int primary key NOT NULL,
Nombre_Centro varchar (50) NOT NULL,
Ciudad varchar (30) NOT NULL
)
SELECT * FROM Directivo

INSERT INTO  Directivo (Id_Directivo, Centro_Supervisado, Prestaci�n_Combustible)
VALUES ('000519', '000201', '1')
INSERT INTO  Directivo (Id_Directivo, Centro_Supervisado, Prestaci�n_Combustible)
VALUES ('000520', '000202', '1')
INSERT INTO  Directivo (Id_Directivo, Centro_Supervisado, Prestaci�n_Combustible)
VALUES ('000521', '000203', '1')
INSERT INTO  Directivo (Id_Directivo, Centro_Supervisado, Prestaci�n_Combustible)
VALUES ('068019', 'La Primavera Ropa', '1')
INSERT INTO  Directivo (Id_Directivo, Centro_Supervisado, Prestaci�n_Combustible)
VALUES ('06808', 'La Primavera Muebles', '0')
INSERT INTO  Directivo (Id_Directivo, Centro_Supervisado, Prestaci�n_Combustible)
VALUES ('06807', 'La Primavera Cajas', '0')
INSERT INTO  Directivo (Id_Directivo, Centro_Supervisado, Prestaci�n_Combustible)
VALUES ('02305', 'La Vada es Bella Ropa', '0')
INSERT INTO  Directivo (Id_Directivo, Centro_Supervisado, Prestaci�n_Combustible)
VALUES ('02306', 'La Vada es Bella Muebles', '1')
INSERT INTO  Directivo (Id_Directivo, Centro_Supervisado, Prestaci�n_Combustible)
VALUES ('02307', 'La Vida es Bella Cajas', '0')


UPDATE Directivo SET Centro_Supervisado= 'La Vida es Bella Ropa' where Id_Directivo=02306

SELECT * FROM Empleado

INSERT INTO Empleado (Nombre, Apellido_Materno,Apellido_Paterno, Fecha_Nacimiento, RFC)
VALUES ('Pilar', 'Barajas', 'Cervantes', '10/01/1990', 'BACP900110MMNRL00')
INSERT INTO Empleado (Nombre, Apellido_Materno,Apellido_Paterno, Fecha_Nacimiento, RFC)
VALUES ('Juan Manuel', 'Corona', 'Corona', '26/02/2000', 'COCJ022620RRLSS00')
INSERT INTO Empleado (Nombre, Apellido_Materno,Apellido_Paterno, Fecha_Nacimiento, RFC)
VALUES ('Jes�s', 'Vega', 'Castro', '27/03/1988', 'VECJ880327TTFOPP9')
INSERT INTO Empleado (Nombre, Apellido_Materno,Apellido_Paterno, Fecha_Nacimiento, RFC)
VALUES ('Jos�', 'L�pez', 'perez', '01/01/1980', 'LOPJ800101NNJMM77')
INSERT INTO Empleado (Nombre, Apellido_Materno,Apellido_Paterno, Fecha_Nacimiento, RFC)
VALUES ('Jos� Audelio', 'Padilla', 'Medrano', '04/12/1971', 'PAMJ711204KKDDD71')
INSERT INTO Empleado (Nombre, Apellido_Materno,Apellido_Paterno, Fecha_Nacimiento, RFC)
VALUES ('Elizebeth', 'Barajas', 'Cervantes', '17/05/1985', 'BACE850517RRYYU85')
INSERT INTO Empleado (Nombre, Apellido_Materno,Apellido_Paterno, Fecha_Nacimiento, RFC)
VALUES ('America', 'Linares', 'Duarte', '24/08/1960', 'LIDA600824CCGGH60')
INSERT INTO Empleado (Nombre, Apellido_Materno,Apellido_Paterno, Fecha_Nacimiento, RFC)
VALUES ('Azul','Casarrubias', 'Reyes', '12/12/1980', 'CARA801212RRUUR80')

SELECT * FROM Puesto

INSERT INTO Puesto (Puesto, Descripci�n_Puesto, Centro_Trabajo, Directivo)
VALUES ('Directivo', 'Gerente', '000201', 'si')
INSERT INTO Puesto (Puesto, Descripci�n_Puesto, Centro_Trabajo, Directivo)
VALUES ('Directivo', 'Gerente', '000202', 'si')
INSERT INTO Puesto (Puesto, Descripci�n_Puesto, Centro_Trabajo, Directivo)
VALUES ('Directivo', 'Gerente', '000203', 'si')
INSERT INTO Puesto (Puesto, Descripci�n_Puesto, Centro_Trabajo, Directivo)
VALUES ('Vendedor', 'Vendedor', '02305', 'No')
INSERT INTO Puesto (Puesto, Descripci�n_Puesto, Centro_Trabajo, Directivo)
VALUES ('Directivo', 'Gerente', '02306', 'Si')
INSERT INTO Puesto (Puesto, Descripci�n_Puesto, Centro_Trabajo, Directivo)
VALUES ('Vendedor', 'Vendedor', '02307', 'No')
INSERT INTO Puesto (Puesto, Descripci�n_Puesto, Centro_Trabajo, Directivo)
VALUES ('Vendedor', 'Vendedor', '06807', 'No')
INSERT INTO Puesto (Puesto, Descripci�n_Puesto, Centro_Trabajo, Directivo)
VALUES ('Vendedor', 'Vendedor', '06808', 'No')
INSERT INTO Puesto (Puesto, Descripci�n_Puesto, Centro_Trabajo, Directivo)
VALUES ('Directivo', 'Gerente', '06819', 'si')


SELECT * FROM Centro

UPDATE Puesto SET Directivo= 'Si' WHERE Id_Puesto=10